For both NASDAQ00-14.csv and NASDAQ15-16.csv, they have two columns. The first column is a stock closing price
 and a second column is a sector number.  Sector numbers have following sector names:

Sector number 1 <- "Finance"
Sector number 2 <- "Industry&Tech"
Sector number 3 <- "Materials"
Sector number 4 <- "Service&LifeStyle"
Sector number 5 <- "Computer".
