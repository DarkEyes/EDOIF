For a simulation datasets, "Sim3Folder.x", the x is the level of uniform noise described in the paper. 

Each folder contains 100 files of simuated datasets in the form of .RData files. In each .RData file, The variable simData3$Values is a vector of real numbers and variable simData3$Group is the corresponding group vectors. For example, individual i has a value simData3$Values[i] and its group is simData3$Group[i].

The groundtruth is that only C5 dominates C1,C2,C3,C4.